var ready2 = function(){
	// $(".hoverforcase").click(function(){
	// 	var caseImage = ($(this).attr("src")).replace("thumb","thumbBox");
	// 	var DesignId = "#hovertry" + $(this).attr("design_id");
	// 	$(DesignId).attr("src",caseImage);
	// });
	// if(window.location.href !== "http://localhost:3000"){
	// 		$(".navbar-default").hide();
	// } else {
	// 	$(".navbar-default").removeClass("navbar-fixed-top");
	// }
};


$(document).ready(ready2);
$(document).on('page:load', ready2);
